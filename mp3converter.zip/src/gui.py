import PySimpleGUI as sg
from pathlib import Path
from src.convert import convert_to_mp3
...