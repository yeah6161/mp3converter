import shutil, subprocess
from pathlib import Path
FFMPEG_NAMES=("ffmpeg.exe","ffmpeg")
...